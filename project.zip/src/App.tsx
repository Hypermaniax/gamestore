import { useEffect, useMemo, useState } from "react";

type IconProps = { className?: string };

const Search = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.7-3.7" />
  </svg>
);

const ArrowUpRight = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M7 17 17 7M8 7h9v9" />
  </svg>
);

const Shield = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M12 3 4.8 6v5.2c0 4.6 3 8.2 7.2 9.8 4.2-1.6 7.2-5.2 7.2-9.8V6L12 3Z" />
    <path d="m9.2 12 1.8 1.8 4-4" />
  </svg>
);

const Spark = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.7"
  >
    <path d="M12 2c.6 5.1 3 8.2 8 9-5 .8-7.4 3.9-8 9-.6-5.1-3-8.2-8-9 5-.8 7.4-3.9 8-9Z" />
  </svg>
);

const Sun = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <circle cx="12" cy="12" r="3.5" />
    <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
  </svg>
);

const Moon = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M20 15.6A8.5 8.5 0 0 1 8.4 4a8.5 8.5 0 1 0 11.6 11.6Z" />
  </svg>
);

const User = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <circle cx="12" cy="8" r="3.5" />
    <path d="M4.5 20c.5-4 3.2-6 7.5-6s7 2 7.5 6" />
  </svg>
);

const Menu = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M4 7h16M4 12h16M4 17h16" />
  </svg>
);

const Check = ({ className = "size-5" }: IconProps) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="m5 12 4 4L19 6" />
  </svg>
);

const Heart = ({ className = "size-5", filled = false }: IconProps & { filled?: boolean }) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill={filled ? "currentColor" : "none"}
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="M12 20s-7-4.6-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.4-7 10-7 10Z" />
  </svg>
);

const Close = ({ className = "size-5" }: IconProps) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
  >
    <path d="m6 6 12 12M18 6 6 18" />
  </svg>
);

type Game = {
  id: number;
  title: string;
  game: string;
  category: string;
  detail: string;
  price: number;
  oldPrice: number;
  tag: string;
  image: string;
  specs: string[];
};

const IMG = {
  a: "https://images.unsplash.com/photo-1559818447-969ea3aa2fbd?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=86&w=900&h=700",
  b: "https://images.unsplash.com/photo-1607896426171-99097eb60cb6?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=86&w=900&h=700",
  c: "https://images.unsplash.com/photo-1586182987320-4f376d39d787?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=86&w=900&h=700",
};

const games: Game[] = [
  {
    id: 1,
    title: "Mythic Glory · 87 Skins",
    game: "Mobile Legends",
    category: "MOBA",
    detail: "Level 71 · 32 Collector",
    price: 1850000,
    oldPrice: 2200000,
    tag: "Hot deal",
    specs: ["Rank Mythic Glory", "87 skin, 12 Legend", "Email & akun sosmed bisa diganti"],
    image:
      "https://images.unsplash.com/photo-1559818447-969ea3aa2fbd?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=86&w=900&h=700",
  },
  {
    id: 2,
    title: "AR 60 · 28 Character",
    game: "Genshin Impact",
    category: "RPG",
    detail: "Asia · 17 Limited 5★",
    price: 2400000,
    oldPrice: 2750000,
    tag: "Pilihan editor",
    specs: ["AR 60, World Level 8", "17 karakter 5★ limited", "Primogem 12.400"],
    image:
      "https://images.unsplash.com/photo-1607896426171-99097eb60cb6?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=86&w=900&h=700",
  },
  {
    id: 3,
    title: "Conqueror · Full Set",
    game: "PUBG Mobile",
    category: "Battle Royale",
    detail: "Level 79 · 6 Upgradable Gun",
    price: 1275000,
    oldPrice: 1500000,
    tag: "Stok baru",
    specs: ["Conqueror musim lalu", "Set outfit langka lengkap", "Bisa ganti email & nomor"],
    image:
      "https://images.unsplash.com/photo-1586182987320-4f376d39d787?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=86&w=900&h=700",
  },
  {
    id: 4,
    title: "Grand Master · 41 Hero",
    game: "Honor of Kings",
    category: "MOBA",
    detail: "Level 30 · 41 Hero",
    price: 640000,
    oldPrice: 780000,
    tag: "Harga terbaik",
    image: IMG.c,
    specs: ["Rank Grand Master", "41 hero, 63 skin", "Binding bisa dipindah"],
  },
  {
    id: 5,
    title: "Rise of Kingdoms · 120M Power",
    game: "Rise of Kingdoms",
    category: "Strategi",
    detail: "Kingdom 2891 · City Hall 25",
    price: 3150000,
    oldPrice: 3600000,
    tag: "Langka",
    image: IMG.a,
    specs: ["City Hall 25", "Legendary commander 14", "Gems 410.000"],
  },
  {
    id: 6,
    title: "Honkai Star Rail · TL 70",
    game: "Honkai: Star Rail",
    category: "RPG",
    detail: "Asia · 9 Limited 5★",
    price: 1120000,
    oldPrice: 1320000,
    tag: "Stok baru",
    image: IMG.b,
    specs: ["Trailblaze Level 70", "9 karakter 5★ limited", "Eidolon tinggi"],
  },
  {
    id: 7,
    title: "Ace Dominator · 52 Outfit",
    game: "Free Fire",
    category: "Battle Royale",
    detail: "Level 72 · 9 Evo Gun",
    price: 890000,
    oldPrice: 990000,
    tag: "Hot deal",
    image: IMG.c,
    specs: ["Rank Heroic", "9 senjata Evo maks", "Bundle Elite Pass lama"],
  },
  {
    id: 8,
    title: "Clash Royale · King 15",
    game: "Clash of Clans",
    category: "Strategi",
    detail: "TH 16 · Maxed Hero",
    price: 1450000,
    oldPrice: 1700000,
    tag: "Pilihan editor",
    image: IMG.a,
    specs: ["Town Hall 16", "Semua hero max", "Skin langka event"],
  },
];

const categories = ["Semua", "MOBA", "RPG", "Battle Royale", "Strategi"];

const sorts = [
  { value: "default", label: "Rekomendasi" },
  { value: "low", label: "Harga terendah" },
  { value: "high", label: "Harga tertinggi" },
  { value: "discount", label: "Diskon terbesar" },
];

const payments = ["QRIS", "BCA VA", "Mandiri VA", "GoPay"];

const discountOf = (item: Game) => Math.round((1 - item.price / item.oldPrice) * 100);

const formatPrice = (price: number) => `Rp${price.toLocaleString("id-ID")}`;

export default function App() {
  const [dark, setDark] = useState(true);
  const [category, setCategory] = useState("Semua");
  const [query, setQuery] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [selected, setSelected] = useState<Game | null>(null);
  const [sort, setSort] = useState("default");
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [user, setUser] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [loginError, setLoginError] = useState<{ email?: string; password?: string }>({});
  const [pendingBuy, setPendingBuy] = useState<Game | null>(null);

  const modalOpen = loginOpen || !!selected;

  const closeModals = () => {
    setLoginOpen(false);
    setSelected(null);
    setLoginError({});
  };

  const notify = (message: string) => setToast(message);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!modalOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeModals();
    };
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [modalOpen]);

  const toggleWishlist = (item: Game) => {
    const has = wishlist.includes(item.id);
    setWishlist((list) => (has ? list.filter((id) => id !== item.id) : [...list, item.id]));
    notify(has ? "Dihapus dari favorit" : `${item.game} disimpan ke favorit`);
  };

  const buy = (item: Game) => {
    if (!user) {
      setPendingBuy(item);
      setSelected(null);
      setLoginOpen(true);
      return;
    }
    setSelected(null);
    notify(`Pesanan ${item.game} dibuat. Lanjut ke pembayaran.`);
  };

  const submitLogin = (event: React.FormEvent) => {
    event.preventDefault();
    const errors: { email?: string; password?: string } = {};
    if (!/^\S+@\S+\.\S+$/.test(loginForm.email)) errors.email = "Masukkan email yang valid";
    if (loginForm.password.length < 8) errors.password = "Password minimal 8 karakter";
    setLoginError(errors);
    if (Object.keys(errors).length) return;
    const name = loginForm.email.split("@")[0];
    setUser(name);
    setLoginOpen(false);
    setLoginForm({ email: "", password: "" });
    if (pendingBuy) {
      notify(`Halo ${name}! Pesanan ${pendingBuy.game} dibuat.`);
      setPendingBuy(null);
    } else notify(`Selamat datang, ${name}`);
  };

  const filteredGames = useMemo(() => {
    const list = games.filter(
      (item) =>
        (category === "Semua" || item.category === category) &&
        `${item.title} ${item.game} ${item.detail}`
          .toLowerCase()
          .includes(query.trim().toLowerCase()),
    );
    if (sort === "low") list.sort((a, b) => a.price - b.price);
    if (sort === "high") list.sort((a, b) => b.price - a.price);
    if (sort === "discount") list.sort((a, b) => discountOf(b) - discountOf(a));
    return list;
  }, [category, query, sort]);

  const countFor = (item: string) =>
    item === "Semua" ? games.length : games.filter((g) => g.category === item).length;

  const resetFilters = () => {
    setCategory("Semua");
    setQuery("");
    setSort("default");
  };

  const scrollToCatalog = () =>
    document.querySelector("#catalog")?.scrollIntoView({ behavior: "smooth" });

  return (
    <div className={dark ? "dark" : ""}>
      <main className="min-h-screen overflow-x-clip bg-[#f3f2ed] text-[#111719] transition-colors duration-300 dark:bg-[#090d11] dark:text-[#f2f5ef]">
        <div className="pointer-events-none fixed inset-0 z-50 opacity-[0.028] mix-blend-soft-light noise" />

        <header
          className={`sticky top-0 z-40 border-b backdrop-blur-xl transition-colors duration-300 ${
            scrolled
              ? "border-black/10 bg-[#f3f2ed]/85 dark:border-white/10 dark:bg-[#090d11]/85"
              : "border-transparent bg-transparent"
          }`}
        >
          <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between px-5 sm:px-8 lg:px-12">
            <button
              className="flex items-center gap-3"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            >
              <span className="grid size-9 rotate-3 place-items-center rounded-[10px] bg-[#c8ff36] text-[#0b0f10] shadow-[0_0_28px_rgba(200,255,54,.18)]">
                <Spark className="size-5" />
              </span>
              <span className="font-display text-xl font-bold tracking-[-0.04em]">
                NEXA<span className="text-[#8bad25] dark:text-[#c8ff36]">PLAY</span>
              </span>
            </button>

            <nav className="hidden items-center gap-8 text-sm font-medium lg:flex">
              <button onClick={scrollToCatalog} className="nav-link">
                Jelajahi
              </button>
              <button
                onClick={() => {
                  setCategory("MOBA");
                  scrollToCatalog();
                }}
                className="nav-link"
              >
                Game
              </button>
              <button
                onClick={() =>
                  document.querySelector("#how")?.scrollIntoView({ behavior: "smooth" })
                }
                className="nav-link"
              >
                Cara beli
              </button>
              <span className="rounded-full border border-[#9cc82a]/40 bg-[#c8ff36]/10 px-3 py-1 text-[11px] font-bold uppercase tracking-[.14em] text-[#688516] dark:text-[#c8ff36]">
                Promo 15%
              </span>
            </nav>

            <div className="flex items-center gap-2">
              <button
                aria-label="Ganti tema"
                onClick={() => setDark((value) => !value)}
                className="icon-button"
              >
                {dark ? <Sun /> : <Moon />}
              </button>
              <button
                onClick={() =>
                  user ? (setUser(null), notify("Kamu sudah keluar")) : setLoginOpen(true)
                }
                title={user ? "Klik untuk keluar" : undefined}
                className="hidden h-11 items-center gap-2 rounded-full border border-black/15 px-5 text-sm font-semibold transition hover:bg-black hover:text-white dark:border-white/15 dark:hover:bg-white dark:hover:text-black sm:flex"
              >
                <User className="size-4" /> {user ? user : "Masuk"}
              </button>
              <button
                onClick={() => setMobileOpen((value) => !value)}
                className="icon-button lg:hidden"
                aria-label="Buka menu"
                aria-expanded={mobileOpen}
              >
                <Menu />
              </button>
            </div>
          </div>
          {mobileOpen && (
            <div className="absolute inset-x-4 top-[72px] rounded-2xl border border-black/10 bg-[#f8f7f2] p-3 shadow-2xl dark:border-white/10 dark:bg-[#13191e] lg:hidden">
              {[
                ["Jelajahi akun", "#catalog"],
                ["Game populer", "#catalog"],
                ["Cara beli", "#how"],
              ].map(([item, target]) => (
                <button
                  key={item}
                  onClick={() => {
                    setMobileOpen(false);
                    document.querySelector(target)?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="block w-full rounded-xl px-4 py-3 text-left text-sm font-semibold hover:bg-black/5 dark:hover:bg-white/5"
                >
                  {item}
                </button>
              ))}
              <button
                onClick={() => {
                  setLoginOpen(true);
                  setMobileOpen(false);
                }}
                className="mt-2 w-full rounded-xl bg-[#c8ff36] px-4 py-3 text-sm font-bold text-[#101510]"
              >
                {user ? `Hai, ${user}` : "Masuk ke akun"}
              </button>
            </div>
          )}
        </header>

        <section className="relative mx-auto max-w-[1440px] px-5 pb-16 pt-10 sm:px-8 lg:px-12 lg:pb-24 lg:pt-16">
          <div className="grid items-center gap-10 lg:grid-cols-[1.02fr_.98fr] lg:gap-16">
            <div className="relative z-10">
              <div className="mb-7 flex items-center gap-3 text-xs font-bold uppercase tracking-[.22em] text-[#657075] dark:text-[#929da3]">
                <span className="h-px w-8 bg-[#99c327]" />
                Marketplace akun game terkurasi
              </div>
              <h1 className="font-display max-w-[740px] text-[clamp(3.6rem,7.5vw,7.7rem)] font-bold leading-[.82] tracking-[-.075em]">
                Main lebih
                <br />
                jauh<span className="text-[#94bc29] dark:text-[#c8ff36]">.</span>
              </h1>
              <p className="mt-7 max-w-xl text-base leading-7 text-[#5f686a] dark:text-[#9da7ab] sm:text-lg">
                Temukan akun game siap pakai dengan detail transparan, transaksi aman, dan garansi
                hingga 14 hari.
              </p>

              <div className="mt-9 flex max-w-2xl flex-col gap-3 rounded-[22px] border border-black/10 bg-white p-2 shadow-[0_18px_70px_rgba(23,31,33,.12)] dark:border-white/10 dark:bg-[#141a1f] sm:flex-row">
                <label className="flex min-w-0 flex-1 items-center gap-3 px-4">
                  <Search className="size-5 shrink-0 text-[#849093]" />
                  <input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    onKeyDown={(event) => event.key === "Enter" && scrollToCatalog()}
                    className="h-12 w-full bg-transparent text-sm outline-none placeholder:text-[#91999b]"
                    placeholder="Cari game, rank, atau akun..."
                  />
                </label>
                <button
                  onClick={scrollToCatalog}
                  className="flex h-12 items-center justify-center gap-2 rounded-[15px] bg-[#c8ff36] px-7 text-sm font-bold text-[#101510] transition hover:bg-[#d5ff67] active:scale-[.98]"
                >
                  Cari akun <ArrowUpRight className="size-4" />
                </button>
              </div>

              <div className="mt-8 flex flex-wrap gap-x-8 gap-y-3">
                {["Akun terverifikasi", "Pembayaran aman", "Garansi akun"].map((item) => (
                  <span
                    key={item}
                    className="flex items-center gap-2 text-xs font-semibold text-[#657075] dark:text-[#aab2b5]"
                  >
                    <span className="grid size-5 place-items-center rounded-full bg-[#c8ff36]/15 text-[#779b19] dark:text-[#c8ff36]">
                      <Check className="size-3" />
                    </span>
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="relative min-h-[440px] lg:min-h-[580px]">
              <div className="absolute -right-28 -top-20 size-[480px] rounded-full bg-[#c8ff36]/10 blur-[100px]" />
              <div className="absolute inset-0 rotate-2 overflow-hidden rounded-[34px] border border-white/10 bg-[#161d22] shadow-[0_30px_100px_rgba(0,0,0,.3)]">
                <img
                  src="https://images.unsplash.com/photo-1607896426171-99097eb60cb6?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=90&w=1200&h=1450"
                  alt="Gaming setup bernuansa neon"
                  className="h-full w-full object-cover opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#070b0e] via-transparent to-[#0a0f13]/20" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-6 sm:p-8">
                  <div>
                    <div className="mb-3 inline-flex rounded-full bg-[#c8ff36] px-3 py-1 text-[10px] font-extrabold uppercase tracking-[.15em] text-[#101510]">
                      Drop minggu ini
                    </div>
                    <p className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">
                      Season-ready accounts
                    </p>
                    <p className="mt-1 text-sm text-white/60">
                      Akun pilihan, siap lanjut push rank.
                    </p>
                  </div>
                  <button
                    onClick={scrollToCatalog}
                    aria-label="Lihat akun terbaru"
                    className="grid size-12 shrink-0 place-items-center rounded-full border border-white/25 bg-white/10 text-white backdrop-blur-md transition hover:rotate-12 hover:bg-[#c8ff36] hover:text-black"
                  >
                    <ArrowUpRight />
                  </button>
                </div>
              </div>
              <div className="absolute -left-5 top-8 rounded-2xl border border-black/10 bg-white/90 p-4 shadow-xl backdrop-blur-md dark:border-white/10 dark:bg-[#12181d]/90 sm:-left-9">
                <div className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-xl bg-[#c8ff36] text-[#111]">
                    <Shield />
                  </span>
                  <div>
                    <p className="text-xs font-bold">Proteksi pembeli</p>
                    <p className="mt-0.5 text-[11px] text-[#7e898c]">Transaksi lebih tenang</p>
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-3 right-5 rounded-2xl border border-white/10 bg-[#11171b]/90 px-5 py-4 text-white shadow-xl backdrop-blur-md sm:right-10">
                <p className="text-[10px] font-bold uppercase tracking-[.18em] text-[#c8ff36]">
                  Live catalog
                </p>
                <p className="mt-1 font-display text-2xl font-bold">248 akun</p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="catalog"
          className="mx-auto max-w-[1440px] px-5 py-20 sm:px-8 lg:px-12 lg:py-28"
        >
          <div className="mb-10 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
            <div>
              <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-[#789a20] dark:text-[#c8ff36]">
                Fresh inventory
              </p>
              <h2 className="font-display text-4xl font-bold tracking-[-.055em] sm:text-5xl">
                Akun pilihan minggu ini
              </h2>
              <p className="mt-3 text-sm text-[#727c7f]">
                Setiap akun unik. Kalau terjual, otomatis hilang dari katalog.
              </p>
            </div>
          </div>

          <div className="sticky top-[72px] z-30 -mx-5 mb-8 border-y border-black/10 bg-[#f3f2ed]/90 px-5 py-3 backdrop-blur-xl dark:border-white/10 dark:bg-[#090d11]/90 sm:-mx-8 sm:px-8 lg:-mx-12 lg:px-12">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
              <label className="flex h-11 items-center gap-3 rounded-full border border-black/10 bg-white px-4 focus-within:border-[#8aaf25] dark:border-white/10 dark:bg-[#141a1f] lg:w-72">
                <Search className="size-4 shrink-0 text-[#849093]" />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  className="w-full bg-transparent text-sm outline-none placeholder:text-[#91999b]"
                  placeholder="Cari di katalog..."
                  aria-label="Cari akun"
                />
                {query && (
                  <button
                    onClick={() => setQuery("")}
                    aria-label="Hapus pencarian"
                    className="text-[#849093] hover:text-current"
                  >
                    <Close className="size-4" />
                  </button>
                )}
              </label>
              <div
                className="hide-scrollbar flex flex-1 gap-2 overflow-x-auto"
                role="tablist"
                aria-label="Kategori game"
              >
                {categories.map((item) => (
                  <button
                    key={item}
                    role="tab"
                    aria-selected={category === item}
                    onClick={() => setCategory(item)}
                    className={`flex shrink-0 items-center gap-2 rounded-full px-4 py-2.5 text-xs font-bold transition ${
                      category === item
                        ? "bg-[#111719] text-white dark:bg-[#c8ff36] dark:text-[#111719]"
                        : "border border-black/10 hover:border-black/30 dark:border-white/10 dark:hover:border-white/30"
                    }`}
                  >
                    {item}
                    <span className="text-[10px] opacity-60">{countFor(item)}</span>
                  </button>
                ))}
              </div>
              <label className="flex items-center gap-2 text-xs font-semibold text-[#727c7f]">
                Urutkan
                <select
                  value={sort}
                  onChange={(event) => setSort(event.target.value)}
                  className="h-11 rounded-full border border-black/10 bg-white px-4 text-xs font-bold text-[#111719] outline-none focus:border-[#8aaf25] dark:border-white/10 dark:bg-[#141a1f] dark:text-white"
                >
                  {sorts.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>
          </div>

          <p className="mb-5 text-xs font-semibold text-[#727c7f]" aria-live="polite">
            Menampilkan {filteredGames.length} dari {games.length} akun
            {category !== "Semua" && ` · ${category}`}
            {query && ` · “${query}”`}
          </p>

          {filteredGames.length ? (
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {filteredGames.map((item) => (
                <article
                  key={item.id}
                  className="group overflow-hidden rounded-[26px] border border-black/10 bg-white transition duration-500 hover:-translate-y-1 hover:shadow-[0_25px_70px_rgba(20,28,30,.12)] dark:border-white/10 dark:bg-[#12181d]"
                >
                  <button
                    onClick={() => setSelected(item)}
                    className="relative block aspect-[1.25] w-full overflow-hidden text-left"
                  >
                    <img
                      src={item.image}
                      alt={`Akun ${item.game}`}
                      className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-black/5" />
                    <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-[.12em] text-black backdrop-blur">
                      {item.tag}
                    </span>
                    <span className="absolute right-4 top-4 rounded-full bg-[#c8ff36] px-2.5 py-1.5 text-[10px] font-extrabold text-[#101510]">
                      -{discountOf(item)}%
                    </span>
                    <span className="absolute bottom-4 left-5 text-xs font-semibold text-white/75">
                      {item.game}
                    </span>
                    <span className="absolute bottom-4 right-4 hidden size-10 translate-y-2 place-items-center rounded-full bg-[#c8ff36] text-black opacity-0 transition group-hover:translate-y-0 group-hover:opacity-100 md:grid">
                      <ArrowUpRight className="size-4" />
                    </span>
                  </button>
                  <div className="p-5 sm:p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-display text-xl font-bold tracking-tight">
                          {item.title}
                        </h3>
                        <p className="mt-1.5 text-xs text-[#788285]">{item.detail}</p>
                      </div>
                      <button
                        onClick={() => toggleWishlist(item)}
                        aria-pressed={wishlist.includes(item.id)}
                        aria-label={
                          wishlist.includes(item.id) ? "Hapus dari favorit" : "Simpan ke favorit"
                        }
                        className={`grid size-9 shrink-0 place-items-center rounded-full border transition active:scale-90 ${
                          wishlist.includes(item.id)
                            ? "border-[#c8ff36] bg-[#c8ff36] text-[#101510]"
                            : "border-black/10 text-[#788285] hover:border-black/30 dark:border-white/10 dark:hover:border-white/30"
                        }`}
                      >
                        <Heart className="size-4" filled={wishlist.includes(item.id)} />
                      </button>
                    </div>
                    <div className="mt-6 flex items-end justify-between border-t border-black/10 pt-5 dark:border-white/10">
                      <div>
                        <p className="text-[11px] text-[#899295] line-through">
                          {formatPrice(item.oldPrice)}
                        </p>
                        <p className="mt-0.5 font-display text-lg font-bold text-[#6f9018] dark:text-[#c8ff36]">
                          {formatPrice(item.price)}
                        </p>
                      </div>
                      <button
                        onClick={() => setSelected(item)}
                        className="rounded-full border border-black/15 px-4 py-2 text-xs font-bold transition hover:bg-black hover:text-white dark:border-white/15 dark:hover:bg-white dark:hover:text-black"
                      >
                        Lihat detail
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="rounded-[26px] border border-dashed border-black/20 py-20 text-center dark:border-white/20">
              <Search className="mx-auto size-8 text-[#8a9496]" />
              <h3 className="mt-4 font-display text-xl font-bold">Akun belum ditemukan</h3>
              <p className="mt-2 text-sm text-[#7d8789]">
                Coba kata kunci lain atau tampilkan semua kategori.
              </p>
              <button
                onClick={resetFilters}
                className="mt-5 text-sm font-bold text-[#75971b] dark:text-[#c8ff36]"
              >
                Reset pencarian
              </button>
            </div>
          )}
        </section>

        <section
          id="how"
          className="mx-5 mb-20 overflow-hidden rounded-[30px] bg-[#11181c] text-white sm:mx-8 lg:mx-12 lg:mb-28"
        >
          <div className="grid lg:grid-cols-[.95fr_1.05fr]">
            <div className="p-8 sm:p-12 lg:p-16">
              <p className="text-xs font-bold uppercase tracking-[.2em] text-[#c8ff36]">
                Dibuat untuk rasa aman
              </p>
              <h2 className="font-display mt-5 text-4xl font-bold leading-[.95] tracking-[-.055em] sm:text-5xl">
                Dari pilih akun
                <br />
                sampai siap main.
              </h2>
              <p className="mt-5 max-w-md text-sm leading-6 text-white/55">
                Kami membuat setiap tahap jelas dan terlindungi. Detail akun transparan, pembayaran
                terverifikasi, kredensial hanya untukmu.
              </p>
            </div>
            <div className="grid border-t border-white/10 sm:grid-cols-3 lg:border-l lg:border-t-0">
              {[
                ["01", "Pilih akun", "Bandingkan rank, item, dan detail akun."],
                ["02", "Bayar aman", "QRIS atau virtual account, diproses otomatis."],
                ["03", "Mulai main", "Reveal kredensial dan nikmati garansi 14 hari."],
              ].map(([number, title, text]) => (
                <div
                  key={number}
                  className="border-b border-white/10 p-8 last:border-b-0 sm:border-b-0 sm:border-r sm:last:border-r-0 lg:p-9"
                >
                  <span className="font-display text-sm font-bold text-[#c8ff36]">{number}</span>
                  <h3 className="mt-16 font-display text-lg font-bold">{title}</h3>
                  <p className="mt-2 text-xs leading-5 text-white/45">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <footer className="border-t border-black/10 dark:border-white/10">
          <div className="mx-auto flex max-w-[1440px] flex-col gap-6 px-5 py-10 sm:px-8 lg:flex-row lg:items-center lg:justify-between lg:px-12">
            <div className="flex items-center gap-3 font-display text-lg font-bold">
              <span className="text-[#8fb629]">✦</span> NEXAPLAY
            </div>
            <p className="text-xs text-[#7c8688]">
              © 2026 NexaPlay. Marketplace akun game terpercaya.
            </p>
            <div className="flex gap-6 text-xs font-semibold text-[#697376] dark:text-[#a5aeb0]">
              <button>Syarat & ketentuan</button>
              <button>Privasi</button>
              <button>Bantuan</button>
            </div>
          </div>
        </footer>

        {modalOpen && (
          <div
            className="fixed inset-0 z-[70] grid place-items-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm"
            onMouseDown={(event) => event.target === event.currentTarget && closeModals()}
          >
            {loginOpen && (
              <form
                noValidate
                role="dialog"
                aria-modal="true"
                aria-labelledby="login-title"
                onSubmit={submitLogin}
                className="w-full max-w-md rounded-[28px] bg-[#f6f5f0] p-7 text-[#111719] shadow-2xl dark:bg-[#12181d] dark:text-[#f2f5ef] sm:p-9"
              >
                <div className="mb-7 flex items-start justify-between">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[.18em] text-[#789a20] dark:text-[#c8ff36]">
                      {pendingBuy ? "Satu langkah lagi" : "Selamat datang"}
                    </p>
                    <h2
                      id="login-title"
                      className="font-display mt-2 text-3xl font-bold tracking-tight"
                    >
                      Masuk ke NexaPlay
                    </h2>
                    {pendingBuy && (
                      <p className="mt-2 text-sm text-black/55 dark:text-white/55">
                        Masuk untuk membeli {pendingBuy.title}.
                      </p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={closeModals}
                    aria-label="Tutup"
                    className="modal-close"
                  >
                    <Close className="size-5" />
                  </button>
                </div>
                <label htmlFor="email" className="text-xs font-bold">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  autoFocus
                  autoComplete="email"
                  value={loginForm.email}
                  onChange={(event) => setLoginForm({ ...loginForm, email: event.target.value })}
                  aria-invalid={!!loginError.email}
                  className="field mt-2"
                  placeholder="nama@email.com"
                />
                {loginError.email && (
                  <p className="mt-1.5 text-xs font-semibold text-red-500">{loginError.email}</p>
                )}
                <label htmlFor="password" className="mt-5 block text-xs font-bold">
                  Password
                </label>
                <input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  value={loginForm.password}
                  onChange={(event) => setLoginForm({ ...loginForm, password: event.target.value })}
                  aria-invalid={!!loginError.password}
                  className="field mt-2"
                  placeholder="Minimal 8 karakter"
                />
                {loginError.password && (
                  <p className="mt-1.5 text-xs font-semibold text-red-500">{loginError.password}</p>
                )}
                <button
                  type="submit"
                  className="mt-6 h-12 w-full rounded-xl bg-[#111719] text-sm font-bold text-white transition hover:bg-[#273033] dark:bg-[#c8ff36] dark:text-[#101510] dark:hover:bg-[#d5ff67]"
                >
                  Masuk
                </button>
                <p className="mt-5 text-center text-xs text-black/50 dark:text-white/50">
                  Belum punya akun?{" "}
                  <button type="button" className="font-bold text-black dark:text-white">
                    Daftar gratis
                  </button>
                </p>
              </form>
            )}
            {selected && (
              <div
                role="dialog"
                aria-modal="true"
                aria-labelledby="detail-title"
                className="grid w-full max-w-3xl overflow-hidden rounded-[28px] bg-[#f6f5f0] text-[#111719] shadow-2xl dark:bg-[#12181d] dark:text-[#f2f5ef] md:grid-cols-[.9fr_1.1fr]"
              >
                <img
                  src={selected.image}
                  alt={selected.game}
                  className="h-52 w-full object-cover md:h-full"
                />
                <div className="p-7 sm:p-9">
                  <div className="flex items-center justify-between">
                    <span className="rounded-full bg-[#dffb8e] px-3 py-1 text-[10px] font-bold uppercase tracking-[.12em] text-[#101510]">
                      {selected.game}
                    </span>
                    <button
                      onClick={() => setSelected(null)}
                      aria-label="Tutup"
                      className="modal-close"
                    >
                      <Close className="size-5" />
                    </button>
                  </div>
                  <h2
                    id="detail-title"
                    className="font-display mt-6 text-3xl font-bold tracking-tight"
                  >
                    {selected.title}
                  </h2>
                  <p className="mt-2 text-sm text-black/50 dark:text-white/50">{selected.detail}</p>
                  <ul className="mt-6 space-y-2.5">
                    {selected.specs.map((value) => (
                      <li key={value} className="flex items-center gap-2.5 text-sm font-medium">
                        <span className="grid size-5 shrink-0 place-items-center rounded-full bg-[#c8ff36]/30 text-[#5f7d12] dark:text-[#c8ff36]">
                          <Check className="size-3" />
                        </span>
                        {value}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 text-[11px] font-semibold text-black/55 dark:text-white/55">
                    {["Kepemilikan dicek", "Garansi 14 hari", "Stok hanya 1"].map((value) => (
                      <span key={value} className="flex items-center gap-1.5">
                        <Shield className="size-3.5" /> {value}
                      </span>
                    ))}
                  </div>
                  <div className="mt-6 flex items-end justify-between border-t border-black/10 pt-5 dark:border-white/10">
                    <div>
                      <p className="text-xs text-black/40 line-through dark:text-white/40">
                        {formatPrice(selected.oldPrice)}
                      </p>
                      <p className="font-display text-2xl font-bold">
                        {formatPrice(selected.price)}
                      </p>
                    </div>
                    <span className="rounded-full bg-[#c8ff36] px-2.5 py-1 text-[10px] font-extrabold text-[#101510]">
                      Hemat {formatPrice(selected.oldPrice - selected.price)}
                    </span>
                  </div>
                  <p className="mt-4 text-[11px] text-black/45 dark:text-white/45">
                    Bayar via {payments.join(" · ")}
                  </p>
                  <div className="mt-4 flex gap-2">
                    <button
                      onClick={() => toggleWishlist(selected)}
                      aria-pressed={wishlist.includes(selected.id)}
                      aria-label="Favorit"
                      className={`grid size-12 shrink-0 place-items-center rounded-xl border transition ${
                        wishlist.includes(selected.id)
                          ? "border-[#c8ff36] bg-[#c8ff36] text-[#101510]"
                          : "border-black/15 dark:border-white/15"
                      }`}
                    >
                      <Heart className="size-5" filled={wishlist.includes(selected.id)} />
                    </button>
                    <button
                      onClick={() => buy(selected)}
                      className="flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-[#c8ff36] text-sm font-bold text-[#101510] transition hover:bg-[#d5ff67] active:scale-[.98]"
                    >
                      {user ? "Beli sekarang" : "Masuk & beli"} <ArrowUpRight className="size-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <div
          role="status"
          aria-live="polite"
          className={`pointer-events-none fixed inset-x-0 bottom-6 z-[80] flex justify-center px-4 transition duration-300 ${
            toast ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
          }`}
        >
          <div className="flex items-center gap-2.5 rounded-full bg-[#111719] px-5 py-3 text-sm font-semibold text-white shadow-2xl dark:bg-[#f2f5ef] dark:text-[#111719]">
            <span className="grid size-5 place-items-center rounded-full bg-[#c8ff36] text-[#101510]">
              <Check className="size-3" />
            </span>
            {toast}
          </div>
        </div>
      </main>
    </div>
  );
}
